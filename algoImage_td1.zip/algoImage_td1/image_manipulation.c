#include <stdio.h>
#include <stdlib.h>
#include "./include/image.h"

int main()
{   
    system("clear");
    int choice;
    pgm_t *pgm_image = NULL;
    ppm_t *ppm_image = NULL;
    while (1)
    {
        printf("\nChoix de l'opération :\n");
        printf("1. Lire une image PGM\n");
        printf("2. Afficher une image PGM\n");
        printf("3. Appliquer le filtre négatif à une image PGM\n");
        printf("4. Calculer l'histogramme d'une image PGM\n");
        printf("5. Lire une image PPM\n");
        printf("6. Afficher une image PPM\n");
        printf("7. Appliquer le filtre négatif à une image PPM\n");
        printf("8. Compresser une image PGM en JPEG\n");
        printf("9. Extraire une sous-image\n");
        printf("10. Extraire un bloc 8x8\n");

        printf("0. Quitter\n");
        printf("Votre choix : ");

        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
        {
            if (pgm_image != NULL)
            {
                pgm_free(pgm_image);
            }
            char fname[100];
            printf("Entrez le nom du fichier PGM : ");
            scanf("%s", fname);
            pgm_image = pgm_read_asc(fname);
            if (pgm_image != NULL)
            {
                printf("Image PGM lue avec succès.\n");
            }
            else
            {
                printf("Échec de la lecture de l'image PGM.\n");
            }
            break;
        }
        case 2:
        {
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            for (int i = 0; i < pgm_image->height; i++)
            {
                for (int j = 0; j < pgm_image->width; j++)
                {
                    printf("%3d ", pgm_image->pixels[i][j]);
                }
                printf("\n");
            }
            break;
        }
        case 3:
        {
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            pgm_t *negative_image = pgm_alloc(pgm_image->width, pgm_image->height, pgm_image->max_value);
            pgm_negative(pgm_image, negative_image);
            pgm_write_asc("negative_image.pgm", negative_image);
            pgm_free(negative_image);
            printf("Négatif de l'image PGM appliqué avec succès. Résultat enregistré dans 'negative_image.pgm'.\n");
            break;
        }
        case 4:
        {
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            int *hist = pgm_get_histogram(pgm_image);
            printf("Histogramme de l'image PGM :\n");
            for (int i = 0; i <= pgm_image->max_value; i++)
            {
                printf("Valeur %d : %d\n", i, hist[i]);
            }
            free(hist);
            break;
        }
        case 5:
        {
            if (ppm_image != NULL)
            {
                ppm_free(ppm_image);
            }
            char fname[100];
            printf("Entrez le nom du fichier PPM : ");
            scanf("%s", fname);
            ppm_image = ppm_read_asc(fname);
            if (ppm_image != NULL)
            {
                printf("Image PPM lue avec succès.\n");
            }
            else
            {
                printf("Échec de la lecture de l'image PPM.\n");
            }
            break;
        }
        case 6:
        {
            if (ppm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PPM.\n");
                break;
            }
            for (int i = 0; i < ppm_image->height; i++)
            {
                for (int j = 0; j < ppm_image->width; j++)
                {
                    printf("(%3d,%3d,%3d) ", ppm_image->pixels[i][j].r, ppm_image->pixels[i][j].g, ppm_image->pixels[i][j].b);
                }
                printf("\n");
            }
            break;
        }
        case 7:
        {
            if (ppm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PPM.\n");
                break;
            }
            ppm_t *negative_image = ppm_alloc(ppm_image->width, ppm_image->height, ppm_image->max_value);
            ppm_negative(ppm_image, negative_image);
            ppm_write_asc("negative_image.ppm", negative_image);
            ppm_free(negative_image);
            printf("Négatif de l'image PPM appliqué avec succès. Résultat enregistré dans 'negative_image.ppm'.\n");
            break;
        }
        case 8:
        {
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            char jpeg_fname[100];
            printf("Entrez le nom du fichier JPEG de sortie : ");
            scanf("%s", jpeg_fname);
            pgm_to_jpeg(pgm_image, jpeg_fname);

            unsigned int pgm_size = fsize(jpeg_fname);
            unsigned int jpeg_size = fsize(jpeg_fname);

            printf("Taille du fichier PGM : %u octets\n", pgm_size);
            printf("Taille du fichier JPEG : %u octets\n", jpeg_size);
            printf("Taux de compression : %.2f\n", (float)pgm_size / jpeg_size);

            break;
        }
        case 9: // Extraire une sous-image
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            printf("Entrez le nom du fichier de sortie : ");
            char out_fname[100];
            scanf("%s", out_fname);
            printf("Entrez les coordonnées dx et dy : ");
            int dx, dy, width, height;
            scanf("%d %d", &dx, &dy);
            printf("Entrez la largeur et la hauteur de la sous-image : ");
            scanf("%d %d", &width, &height);
            pgm_extract(out_fname,pgm_image, dx, dy, width, height);
            printf("pgm_extract de l'image PGM appliqué avec succès. Résultat enregistré '.\n");

            break;

        case 10: // Extraire un bloc 8x8
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            printf("Entrez les coordonnées i et j du bloc 8x8 : ");
            int i, j;
            scanf("%d %d", &i, &j);
            double blk[8][8];
            pgm_extract_blk(pgm_image, blk, i, j);
            afficher_bloc(blk);
            printf("pgm_extract_BLK de l'image PGM appliqué avec succès. Résultat enregistré '.\n");
            break;
        case 0:
        {
            if (pgm_image != NULL)
            {
                pgm_free(pgm_image);
            }
            if (ppm_image != NULL)
            {
                ppm_free(ppm_image);
            }
            printf("Quitter.\n");
            exit(EXIT_SUCCESS);
        }
        default:
            printf("Choix invalide.\n");
            break;
        }
    }

    return 0;
}
