#ifndef IMAGE_H
#define IMAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Définition de la structure PGM
typedef struct {
    int width, height, max_value;
    unsigned char **pixels;
} pgm_t;

// Définition de la structure RGB pour les images PPM
typedef struct {
    unsigned char r, g, b;
} rgb_t;

// Définition de la structure PPM
typedef struct {
    int width, height, max_value;
    rgb_t **pixels;
} ppm_t;


// Fonctions pour manipuler les images PPM
void ppm_negative(ppm_t *src, ppm_t *dst);
ppm_t *ppm_alloc(int width, int height, int max_value);
void ppm_free(ppm_t *image);
ppm_t *ppm_read_asc(const char *fname);
int ppm_write_asc(const char *fname, ppm_t *image);
ppm_t *ppm_read_bin(const char *fname);
int ppm_write_bin(const char *fname, ppm_t *image);
void ppm_extract(const char *fname, ppm_t *image, int dx, int dy, int width, int height);
int **ppm_get_histogram(ppm_t *image);
int ppm_write_histogram(const char *fname, ppm_t *image);
void ppm_to_pgm(ppm_t *src, pgm_t *dst);
// Fonctions pour manipuler les images PGM
pgm_t *pgm_alloc(int width, int height, int max_value);
void pgm_free(pgm_t *image);
pgm_t *pgm_read_asc(const char *fname);
int pgm_write_asc(const char *fname, pgm_t *image);
pgm_t *pgm_read_bin(const char *fname);
int pgm_write_bin(const char *fname, pgm_t *image);
void pgm_negative(pgm_t *src, pgm_t *dst);
void pgm_extract(char *fname, pgm_t *image, int dx, int dy, int width, int height);
int *pgm_get_histogram(pgm_t *image);
int pgm_write_histogram(const char *fname, pgm_t *image);
void pgm_extract_blk(pgm_t *inpgm, double blk[8][8], int i, int j);
void pgm_dct(double blk[8][8]);
void pgm_quantify(double blk[8][8], double Q[8][8]);
void pgm_zigzag_extract(double blk[8][8], int zgzg[64]);
void pgm_rle(FILE *fd, int zgzg[64]);
void pgm_to_jpeg(pgm_t *in_pgm, const char *fname);
unsigned int fsize(const char *fname);
void afficher_bloc(double D[8][8]);



#endif // IMAGE_H
