#include <stdio.h>
#include <stdlib.h>
#include "./include/image.h"

int main()
{
    system("clear");

    int choice;
    pgm_t *pgm_image = NULL;
    ppm_t *ppm_image = NULL;

    while (1)
    {
        printf("\nChoix de l'opération :\n");
        printf("1. Lire une image PGM\n");
        printf("2. Afficher une image PGM\n");
        printf("3. Appliquer le filtre négatif à une image PGM\n");
        printf("4. Lire une image PPM\n");
        printf("5. Afficher une image PPM\n");
        printf("6. Appliquer le filtre négatif à une image PPM\n");
        printf("7. Appliquer une rotation à une image PGM\n");
        printf("8. Appliquer une rotation à une image PPM\n");
        printf("9. Appliquer un zoom à une image PPM\n");
        printf("10. Appliquer un cisaillement à une image PPM\n");
        printf("11. Appliquer une transformation affine à une image PPM\n");
        printf("0. Quitter\n");
        printf("Votre choix : ");

        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
        {
            if (pgm_image != NULL)
            {
                pgm_free(pgm_image);
            }
            char fname[100];
            printf("Entrez le nom du fichier PGM : ");
            scanf("%s", fname);
            pgm_image = pgm_read_asc(fname);
            if (pgm_image != NULL)
            {
                printf("Image PGM lue avec succès.\n");
            }
            else
            {
                printf("Échec de la lecture de l'image PGM.\n");
            }
            break;
        }
        case 2:
        {
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            for (int i = 0; i < pgm_image->height; i++)
            {
                for (int j = 0; j < pgm_image->width; j++)
                {
                    printf("%3d ", pgm_image->pixels[i][j]);
                }
                printf("\n");
            }
            break;
        }
        case 3:
        {
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            pgm_t *negative_image = pgm_alloc(pgm_image->width, pgm_image->height, pgm_image->max_value);
            pgm_negative(pgm_image, negative_image);
            pgm_write_asc("negative_image.pgm", negative_image);
            pgm_free(negative_image);
            printf("Négatif de l'image PGM appliqué avec succès. Résultat enregistré dans 'negative_image.pgm'.\n");
            break;
        }
        case 4:
        {
            if (ppm_image != NULL)
            {
                ppm_free(ppm_image);
            }
            char fname[100];
            printf("Entrez le nom du fichier PPM : ");
            scanf("%s", fname);
            ppm_image = ppm_read_asc(fname);
            if (ppm_image != NULL)
            {
                printf("Image PPM lue avec succès.\n");
            }
            else
            {
                printf("Échec de la lecture de l'image PPM.\n");
            }
            break;
        }
        case 5:
        {
            if (ppm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PPM.\n");
                break;
            }
            for (int i = 0; i < ppm_image->height; i++)
            {
                for (int j = 0; j < ppm_image->width; j++)
                {
                    printf("(%3d,%3d,%3d) ", ppm_image->pixels[i][j].r, ppm_image->pixels[i][j].g, ppm_image->pixels[i][j].b);
                }
                printf("\n");
            }
            break;
        }
        case 6:
        {
            if (ppm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PPM.\n");
                break;
            }
            ppm_t *negative_image = ppm_alloc(ppm_image->width, ppm_image->height, ppm_image->max_value);
            ppm_negative(ppm_image, negative_image);
            ppm_write_asc("negative_image.ppm", negative_image);
            ppm_free(negative_image);
            printf("Négatif de l'image PPM appliqué avec succès. Résultat enregistré dans 'negative_image.ppm'.\n");
            break;
        }
        case 7:
        {
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            double theta;
            int x0, y0;
            printf("Entrez l'angle de rotation (en radians) : ");
            scanf("%lf", &theta);
            printf("Entrez les coordonnées du centre de rotation (x0 y0) : ");
            scanf("%d %d", &x0, &y0);
            pgm_t *rotated_image = rotation_pgm(pgm_image, theta, x0, y0);
            pgm_write_asc("rotated_image.pgm", rotated_image);
            pgm_free(rotated_image);
            printf("Rotation appliquée avec succès. Résultat enregistré dans 'rotated_image.pgm'.\n");
            break;
        }
        case 8:
        {
            if (ppm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PPM.\n");
                break;
            }
            double theta;
            int x0, y0;
            printf("Entrez l'angle de rotation (en radians) : ");
            scanf("%lf", &theta);
            printf("Entrez les coordonnées du centre de rotation (x0 y0) : ");
            scanf("%d %d", &x0, &y0);
            ppm_t *rotated_image = rotation_ppm(ppm_image, theta, x0, y0);
            ppm_write_asc("rotated_image.ppm", rotated_image);
            ppm_free(rotated_image);
            printf("Rotation appliquée avec succès. Résultat enregistré dans 'rotated_image.ppm'.\n");
            break;
        }
        case 9:
        {
            if (ppm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PPM.\n");
                break;
            }
            double lambda;
            int x0, y0, Dx, Dy;
            printf("Entrez le facteur de zoom : ");
            scanf("%lf", &lambda);
            printf("Entrez les coordonnées du centre de zoom (x0 y0) : ");
            scanf("%d %d", &x0, &y0);
            printf("Entrez les dimensions de l'image résultante (Dx Dy) : ");
            scanf("%d %d", &Dx, &Dy);
            ppm_t *zoomed_image = zoom(ppm_image, lambda, x0, y0, Dx, Dy);
            ppm_write_asc("zoomed_image.ppm", zoomed_image);
            ppm_free(zoomed_image);
            printf("Zoom appliqué avec succès. Résultat enregistré dans 'zoomed_image.ppm'.\n");
            break;
        }
        case 10:
        {
            if (ppm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PPM.\n");
                break;
            }
            double cx, cy;
            int Dx, Dy;
            printf("Entrez les facteurs de cisaillement (cx cy) : ");
            scanf("%lf %lf", &cx, &cy);
            printf("Entrez les dimensions de l'image résultante (Dx Dy) : ");
            scanf("%d %d", &Dx, &Dy);
            ppm_t *sheared_image = shear(ppm_image, cx, cy, Dx, Dy);
            ppm_write_asc("sheared_image.ppm", sheared_image);
            ppm_free(sheared_image);
            printf("Cisaillement appliqué avec succès. Résultat enregistré dans 'sheared_image.ppm'.\n");
            break;
        }
        case 11:
        {
            if (ppm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PPM.\n");
                break;
            }
            point_t X_start[3], X_end[3];
            printf("Entrez les coordonnées de trois points de départ (x0 y0 x1 y1 x2 y2) : ");
            for (int i = 0; i < 3; i++)
            {
                scanf("%d %d", &X_start[i].x, &X_start[i].y);
            }
            printf("Entrez les coordonnées des trois points d'arrivée (x0 y0 x1 y1 x2 y2) : ");
            for (int i = 0; i < 3; i++)
            {
                scanf("%d %d", &X_end[i].x, &X_end[i].y);
            }
            double *coeff_transformation = get_affine_transformation(X_start, X_end);
            ppm_t *transformed_image = affine_transformation(ppm_image, coeff_transformation);
            ppm_write_asc("transformed_image.ppm", transformed_image);
            ppm_free(transformed_image);
            free(coeff_transformation);
            printf("Transformation affine appliquée avec succès. Résultat enregistré dans 'transformed_image.ppm'.\n");
            break;
        }
        case 0:
        {
            if (pgm_image != NULL)
            {
                pgm_free(pgm_image);
            }
            if (ppm_image != NULL)
            {
                ppm_free(ppm_image);
            }
            printf("Quitter.\n");
            exit(EXIT_SUCCESS);
        }
        default:
            printf("Choix invalide.\n");
            break;
        }
    }

    return 0;
}