#include "./include/image.h"
#include <math.h>

#define N 1 // Interpolation d'ordre 1

// Déclaration des fonctions d'interpolation
double B0(double x)
{
    return (fabs(x) > 0.5) ? 0 : 1;
}

double B1(double x)
{
    if (fabs(x) > 1)
        return 0;
    if (x <= 0)
        return x + 1;
    return 1 - x;
}

double B2(double x)
{
    if (fabs(x) > 1.5)
        return 0;
    if (x <= -0.5)
        return 0.5 * (x + 1.5) * (x + 1.5);
    if (x <= 0.5)
        return 0.75 - x * x;
    return 0.5 * (x - 1.5) * (x - 1.5);
}

double B3(double x)
{
    if (fabs(x) > 2)
        return 0;
    if (fabs(x) <= 1)
        return 0.5 * fabs(x * x * x) - x * x + 2 / 3.0;
    return 1 / 6.0 * pow(2 - fabs(x), 3);
}

double (*B[4])(double) = {B0, B1, B2, B3};

unsigned char interpolation_pgm(pgm_t *image, double x, double y)
{
    int x0 = (int)x;
    int y0 = (int)y;
    double dx = x - x0;
    double dy = y - y0;

    double sum = 0;
    double norm = 0;
    for (int m = -N; m <= N; m++)
    {
        for (int n = -N; n <= N; n++)
        {
            if (x0 + m >= 0 && x0 + m < image->width && y0 + n >= 0 && y0 + n < image->height)
            {
                double weight = B[N](m - dx) * B[N](n - dy);
                sum += image->pixels[y0 + n][x0 + m] * weight;
                norm += weight;
            }
        }
    }

    return (unsigned char)(sum / norm);
}

rgb_t interpolation_ppm(ppm_t *image, double x, double y)
{
    int x0 = (int)x;
    int y0 = (int)y;
    double dx = x - x0;
    double dy = y - y0;

    double sum_r = 0, sum_g = 0, sum_b = 0;
    double norm = 0;
    for (int m = -N; m <= N; m++)
    {
        for (int n = -N; n <= N; n++)
        {
            if (x0 + m >= 0 && x0 + m < image->width && y0 + n >= 0 && y0 + n < image->height)
            {
                double weight = B[N](m - dx) * B[N](n - dy);
                sum_r += image->pixels[y0 + n][x0 + m].r * weight;
                sum_g += image->pixels[y0 + n][x0 + m].g * weight;
                sum_b += image->pixels[y0 + n][x0 + m].b * weight;
                norm += weight;
            }
        }
    }

    rgb_t result;
    result.r = (unsigned char)(sum_r / norm);
    result.g = (unsigned char)(sum_g / norm);
    result.b = (unsigned char)(sum_b / norm);
    return result;
}

pgm_t *rotation_pgm(pgm_t *image, double theta, int x0, int y0)
{
    pgm_t *result = pgm_alloc(image->width, image->height, image->max_value);
    double thetad = theta * M_PI / 180;
    for (int i = 0; i < image->height; i++)
    {
        for (int j = 0; j < image->width; j++)
        {
            double x = cos(thetad) * (j - x0) - sin(thetad) * (i - y0) + x0;
            double y = sin(thetad) * (j - x0) + cos(thetad) * (i - y0) + y0;
            result->pixels[i][j] = interpolation_pgm(image, x, y);
        }
    }

    return result;
}

ppm_t *rotation_ppm(ppm_t *image, double theta, int x0, int y0)
{
    ppm_t *result = ppm_alloc(image->width, image->height, image->max_value);
    double thetad = theta * M_PI / 180;
    for (int i = 0; i < image->height; i++)
    {
        for (int j = 0; j < image->width; j++)
        {
            double x = cos(thetad) * (j - x0) - sin(thetad) * (i - y0) + x0;
            double y = sin(thetad) * (j - x0) + cos(thetad) * (i - y0) + y0;
            result->pixels[i][j] = interpolation_ppm(image, x, y);
        }
    }

    return result;
}

ppm_t *zoom(ppm_t *image, double lambda, int x0, int y0, int Dx, int Dy)
{
    // debug
    printf("la fct zomm commence\n");
    ppm_t *zoomed_image = ppm_alloc(Dx, Dy, image->max_value);
    printf("alloc marche\n");

    int x, y;
    double xp, yp;

    for (x = 0; x < Dx; x++)
    {
        for (y = 0; y < Dy; y++)
        {
            xp = (x - x0) / lambda + x0;
            yp = (y - y0) / lambda + y0;

            if (xp >= 0 && xp < image->width && yp >= 0 && yp < image->height)
            {

                rgb_t interpolated_color = interpolation_ppm(image, xp, yp);
                zoomed_image->pixels[y][x] = interpolated_color;
            }
            else
            {
                // Gérer les pixels en dehors de l'image originale (par exemple, les mettre à zéro)
                zoomed_image->pixels[y][x].r = 0;
                zoomed_image->pixels[y][x].g = 0;
                zoomed_image->pixels[y][x].b = 0;
            }
        }
    }
    printf("la fct zomm est fini\n");

    return zoomed_image;
}

ppm_t *shear(ppm_t *image, double cx, double cy, int Dx, int Dy)
{
    printf("cc cv?\n");
    ppm_t *result = ppm_alloc(Dx, Dy, image->max_value);
    printf("cv et toi?\n");

    for (int i = 0; i < Dy; i++)
    {
        for (int j = 0; j < Dx; j++)
        {
            printf("moi? ca vaaa\n");

            double x = j - cx * i;
            double y = i - cy * j;
            if (x >= 0 && y < image->width && y >= 0 && y < image->height)
            {
                rgb_t interpolated_color = interpolation_ppm(image, x, y);
                result->pixels[i][j] = interpolated_color;
            }
            else
            {
                // Gérer les pixels en dehors de l'image originale (par exemple, les mettre à zéro)
                result->pixels[i][j].r = 0;
                result->pixels[i][j].g = 0;
                result->pixels[i][j].b = 0;
            }
        }
    }

    return result;
}

double *get_affine_transformation(point_t X_start[3], point_t X_end[3])
{
    double *coeff = malloc(6 * sizeof(double));
    double A[6][6], B[6];
    for (int i = 0; i < 3; i++)
    {
        A[i * 2][0] = X_start[i].x;
        A[i * 2][1] = X_start[i].y;
        A[i * 2][2] = 1;
        A[i * 2][3] = 0;
        A[i * 2][4] = 0;
        A[i * 2][5] = 0;
        B[i * 2] = X_end[i].x;

        A[i * 2 + 1][0] = 0;
        A[i * 2 + 1][1] = 0;
        A[i * 2 + 1][2] = 0;
        A[i * 2 + 1][3] = X_start[i].x;
        A[i * 2 + 1][4] = X_start[i].y;
        A[i * 2 + 1][5] = 1;
        B[i * 2 + 1] = X_end[i].y;
    }
    for (int i = 0; i < 6; i++)
    {
        double max = fabs(A[i][i]);
        int maxRow = i;
        for (int k = i + 1; k < 6; k++)
        {
            if (fabs(A[k][i]) > max)
            {
                max = fabs(A[k][i]);
                maxRow = k;
            }
        }
        for (int k = i; k < 6; k++)
        {
            double tmp = A[maxRow][k];
            A[maxRow][k] = A[i][k];
            A[i][k] = tmp;
        }
        double tmp = B[maxRow];
        B[maxRow] = B[i];
        B[i] = tmp;

        for (int k = i + 1; k < 6; k++)
        {
            double f = A[k][i] / A[i][i];
            for (int j = i; j < 6; j++)
            {
                A[k][j] -= A[i][j] * f;
            }
            B[k] -= B[i] * f;
        }
    }

    for (int i = 5; i >= 0; i--)
    {
        coeff[i] = B[i] / A[i][i];
        for (int k = i - 1; k >= 0; k--)
        {
            B[k] -= A[k][i] * coeff[i];
        }
    }

    return coeff;
}

ppm_t *affine_transformation(ppm_t *image, double *coeff)
{
    ppm_t *result = ppm_alloc(image->width, image->height, image->max_value);

    for (int i = 0; i < image->height; i++)
    {
        for (int j = 0; j < image->width; j++)
        {
            double x = coeff[0] * j + coeff[1] * i + coeff[2];
            double y = coeff[3] * j + coeff[4] * i + coeff[5];
            result->pixels[i][j] = interpolation_ppm(image, x, y);
        }
    }

    return result;
}
