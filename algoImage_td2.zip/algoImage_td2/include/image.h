#ifndef IMAGE_H
#define IMAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Définition de la structure PGM
typedef struct {
    int width, height, max_value;
    unsigned char **pixels;
} pgm_t;

// Définition de la structure RGB pour les images PPM
typedef struct {
    unsigned char r, g, b;
} rgb_t;

// Définition de la structure PPM
typedef struct {
    int width, height, max_value;
    rgb_t **pixels;
} ppm_t;

// Définition de la structure point_t
typedef struct {
    int x, y;
} point_t;

// Fonctions pour manipuler les images PGM
pgm_t *pgm_alloc(int width, int height, int max_value);
void pgm_free(pgm_t *image);
pgm_t *pgm_read_asc(const char *fname);
int pgm_write_asc(const char *fname, pgm_t *image);
pgm_t *pgm_read_bin(const char *fname);
int pgm_write_bin(const char *fname, pgm_t *image);
void pgm_negative(pgm_t *src, pgm_t *dst);
void pgm_extract(const char *fname, pgm_t *image, int dx, int dy, int width, int height);
int *pgm_get_histogram(pgm_t *image);
int pgm_write_histogram(const char *fname, pgm_t *image);

// Fonctions pour manipuler les images PPM
ppm_t *ppm_alloc(int width, int height, int max_value);
void ppm_free(ppm_t *image);
ppm_t *ppm_read_asc(const char *fname);
int ppm_write_asc(const char *fname, ppm_t *image);
ppm_t *ppm_read_bin(const char *fname);
int ppm_write_bin(const char *fname, ppm_t *image);
void ppm_negative(ppm_t *src, ppm_t *dst);
void ppm_extract(const char *fname, ppm_t *image, int dx, int dy, int width, int height);
int **ppm_get_histogram(ppm_t *image);
int ppm_write_histogram(const char *fname, ppm_t *image);
void ppm_to_pgm(ppm_t *src, pgm_t *dst);

// Fonctions de transformation
unsigned char interpolation_pgm(pgm_t *image, double x, double y);
rgb_t interpolation_ppm(ppm_t *image, double x, double y);
pgm_t *rotation_pgm(pgm_t *image, double theta, int x0, int y0);
ppm_t *rotation_ppm(ppm_t *image, double theta, int x0, int y0);
ppm_t *zoom(ppm_t *image, double lambda, int x0, int y0, int Dx, int Dy);
ppm_t *shear(ppm_t *image, double cx, double cy, int Dx, int Dy);
double *get_affine_transformation(point_t X_start[3], point_t X_end[3]);
ppm_t *affine_transformation(ppm_t *image, double *coeff);

#endif // IMAGE_H
