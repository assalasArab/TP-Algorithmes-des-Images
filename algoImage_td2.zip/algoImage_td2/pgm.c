#include "./include/image.h"

// Allocation d'une structure PGM
pgm_t *pgm_alloc(int width, int height, int max_value) {
    pgm_t *image = malloc(sizeof(pgm_t));
    image->width = width;
    image->height = height;
    image->max_value = max_value;
    image->pixels = malloc(height * sizeof(unsigned char *));
    for (int i = 0; i < height; i++) {
        image->pixels[i] = malloc(width * sizeof(unsigned char));
    }
    return image;
}

// Libération de la mémoire d'une structure PGM
void pgm_free(pgm_t *image) {
    for (int i = 0; i < image->height; i++) {
        free(image->pixels[i]);
    }
    free(image->pixels);
    free(image);
}

// Lecture d'une image PGM en ASCII
pgm_t *pgm_read_asc(const char *fname) {
    int hauteur, largeur;
    pgm_t *S;
    char *commentaire = NULL;
    size_t len = 0;
    FILE *fic = fopen(fname, "r");

    if (fic != NULL) {
        // Ignorer les valeurs inutiles
        getline(&commentaire, &len, fic);
        while (commentaire[0] == '#' || commentaire[0] == 'P') {
            getline(&commentaire, &len, fic); // à la fin on a height et width dans commentaire
        }

        // Allocation et initialisation de la structure PGM
        S = (pgm_t *)malloc(sizeof(pgm_t));
        if (S == NULL) {
            fprintf(stderr, "Erreur d'allocation de mémoire pour la structure PGM.\n");
            exit(EXIT_FAILURE);
        }

        // Mise en place de width et height
        sscanf(commentaire, "%d %d", &S->width, &S->height);

        // Mise en place de max_value
        fscanf(fic, "%d", &S->max_value);

        // Allocation du tableau
        S->pixels = (unsigned char **)malloc(S->height * sizeof(unsigned char *));
        for (hauteur = 0; hauteur < S->height; hauteur++) {
            S->pixels[hauteur] = (unsigned char *)malloc(S->width * sizeof(unsigned char));
        }

        // Remplissage du tableau
        for (hauteur = 0; hauteur < S->height; hauteur++) {
            for (largeur = 0; largeur < S->width; largeur++) {
                fscanf(fic, "%hhu", &S->pixels[hauteur][largeur]);
                printf("%hhu",S->pixels[hauteur][largeur]);
            }
        }
        fclose(fic);
        if (commentaire)
            free(commentaire);
    } else {
        printf("Erreur d'ouverture du fichier");
        exit(EXIT_FAILURE);
    }

    return S;
}


// Écriture d'une image PGM en ASCII
int pgm_write_asc(const char *fname, pgm_t *image) {
    int i, j;
    FILE *fic = fopen(fname, "w");

    if (fic == NULL) {
        printf("Erreur d'ouverture du fichier");
        return -1;
    }

    fprintf(fic, "P2\n");
    fprintf(fic, "%d %d\n", image->width, image->height);
    fprintf(fic, "%d\n", image->max_value);
    for (i = 0; i < image->height; i++) {
        for (j = 0; j < image->width; j++) {
            fprintf(fic, "%d\n", image->pixels[i][j]);
        }
    }
    fclose(fic);
    return 0;
}

// Lecture d'une image PGM en binaire
pgm_t *pgm_read_bin(const char *fname) {
    FILE *file = fopen(fname, "rb");
    if (!file) return NULL;

    pgm_t *image = malloc(sizeof(pgm_t));
    fscanf(file, "P5\n%d %d\n%d\n", &image->width, &image->height, &image->max_value);

    image->pixels = malloc(image->height * sizeof(unsigned char *));
    for (int i = 0; i < image->height; i++) {
        image->pixels[i] = malloc(image->width * sizeof(unsigned char));
        fread(image->pixels[i], sizeof(unsigned char), image->width, file);
    }

    fclose(file);
    return image;
}

// Écriture d'une image PGM en binaire
int pgm_write_bin(const char *fname, pgm_t *image) {
    FILE *file = fopen(fname, "wb");
    if (!file) return 1;

    fprintf(file, "P5\n%d %d\n%d\n", image->width, image->height, image->max_value);
    for (int i = 0; i < image->height; i++) {
        fwrite(image->pixels[i], sizeof(unsigned char), image->width, file);
    }

    fclose(file);
    return 0;
}

// Application du filtre négatif à une image PGM
void pgm_negative(pgm_t *src, pgm_t *dst) {
    dst->width = src->width;
    dst->height = src->height;
    dst->max_value = src->max_value;
    dst->pixels = malloc(src->height * sizeof(unsigned char *));
    for (int i = 0; i < src->height; i++) {
        dst->pixels[i] = malloc(src->width * sizeof(unsigned char));
        for (int j = 0; j < src->width; j++) {
            dst->pixels[i][j] = src->max_value - src->pixels[i][j];
        }
    }
}

// Extraction d'une sous-image d'une image PGM
void pgm_extract(const char *fname, pgm_t *image, int dx, int dy, int width, int height) {
    FILE *file = fopen(fname, "w");
    if (!file) return;

    fprintf(file, "P2\n%d %d\n%d\n", width, height, image->max_value);
    for (int i = dy; i < dy + height; i++) {
        for (int j = dx; j < dx + width; j++) {
            fprintf(file, "%d ", image->pixels[i][j]);
        }
        fprintf(file, "\n");
    }

    fclose(file);
}

// Calcul de l'histogramme des pixels d'une image PGM
int *pgm_get_histogram(pgm_t *image) {
    int *histogram = calloc(image->max_value + 1, sizeof(int));
    for (int i = 0; i < image->height; i++) {
        for (int j = 0; j < image->width; j++) {
            histogram[image->pixels[i][j]]++;
        }
    }
    return histogram;
}

// Écriture de l'histogramme d'une image PGM dans un fichier
int pgm_write_histogram(const char *fname, pgm_t *image) {
    FILE *file = fopen(fname, "w");
    if (!file) return 1;

    int *histogram = pgm_get_histogram(image);
    for (int i = 0; i <= image->max_value; i++) {
        fprintf(file, "%d %d\n", i, histogram[i]);
    }

    free(histogram);
    fclose(file);
    return 0;
}
