#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "./include/image.h"

int main()
{
    system("clear");

    int choice;
    pgm_t *pgm_image = NULL;

    while (1)
    {
        printf("\nChoix de l'opération :\n");
        printf("1. Lire une image PGM\n");
        printf("2. Appliquer le filtre de détection de contours naïf\n");
        printf("3. Appliquer le filtre de détection de contours Sobel\n");
        printf("4. Appliquer le filtre de détection de contours Canny\n");
        printf("5. Quitter\n");
        printf("Votre choix : ");

        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
        {
            // Lire une image PGM
            if (pgm_image != NULL)
            {
                pgm_free(pgm_image);
            }
            char fname[100];
            printf("Entrez le nom du fichier PGM : ");
            scanf("%s", fname);
            pgm_image = pgm_read_asc(fname);
            if (pgm_image != NULL)
            {
                printf("Image PGM lue avec succès.\n");
            }
            else
            {
                printf("Échec de la lecture de l'image PGM.\n");
            }
            break;
        }
        case 2:
        {
            // Appliquer le filtre de détection de contours naïf
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            pgm_t *naive_result = naive_edge_detector(pgm_image);
            pgm_write_asc("naive_edges.pgm", naive_result);
            pgm_free(naive_result);
            printf("Détection de contours naïf appliquée avec succès. Résultat enregistré dans 'naive_edges.pgm'.\n");
            break;
        }
        case 3:
        {
            // Appliquer le filtre de détection de contours Sobel
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            pgm_t *sobel_result = sobel_edge_detector(pgm_image);
            pgm_write_asc("sobel_edges.pgm", sobel_result);
            pgm_free(sobel_result);
            printf("Détection de contours Sobel appliquée avec succès. Résultat enregistré dans 'sobel_edges.pgm'.\n");
            break;
        }
        case 4:
        {
            // Appliquer le filtre de détection de contours Canny
            if (pgm_image == NULL)
            {
                printf("Veuillez d'abord lire une image PGM.\n");
                break;
            }
            double sigma;
            int n;
            printf("Entrez la valeur de sigma pour le filtre gaussien : ");
            scanf("%lf", &sigma);
            printf("Entrez la taille du filtre (n doit être impair) : ");
            scanf("%d", &n);
            pgm_t *canny_result = canny_edge_detector(pgm_image, sigma, n);
            pgm_write_asc("canny_edges.pgm", canny_result);
            pgm_free(canny_result);
            printf("Détection de contours Canny appliquée avec succès. Résultat enregistré dans 'canny_edges.pgm'.\n");
            break;
        }
        case 5:
        {
            // Quitter
            if (pgm_image != NULL)
            {
                pgm_free(pgm_image);
            }
            printf("Quitter.\n");
            exit(EXIT_SUCCESS);
        }
        default:
            printf("Choix invalide.\n");
            break;
        }
    }

    return 0;
}
