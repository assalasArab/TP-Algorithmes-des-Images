gcc -o edge_detection edge_detection.c pgm.c canny.c -lm

Exemple pour appliquer le filtre naïf
bash
Copier le code
./edge_detection input_image.pgm naive
Exemple pour appliquer le filtre Sobel
bash
Copier le code
./edge_detection input_image.pgm sobel
Exemple pour appliquer le filtre Canny
bash
Copier le code
./edge_detection input_image.pgm canny 1.0 3 0.2 0.1