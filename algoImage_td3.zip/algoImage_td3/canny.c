#include "./include/image.h"
#include <math.h>

// Filtre gaussien
void gaussian_blur(pgm_t *image, double sigma, int n) {
    int p = n / 2;
    double kernel[n][n];
    double sum = 0.0;

    for (int i = -p; i <= p; i++) {
        for (int j = -p; j <= p; j++) {
            kernel[i + p][j + p] = exp(-(i * i + j * j) / (2 * sigma * sigma)) / (2 * M_PI * sigma * sigma);
            sum += kernel[i + p][j + p];
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            kernel[i][j] /= sum;
        }
    }

    pgm_t *temp = pgm_alloc(image->width, image->height, image->max_value);
    for (int i = p; i < image->height - p; i++) {
        for (int j = p; j < image->width - p; j++) {
            double val = 0.0;
            for (int k = -p; k <= p; k++) {
                for (int l = -p; l <= p; l++) {
                    val += image->pixels[i + k][j + l] * kernel[k + p][l + p];
                }
            }
            temp->pixels[i][j] = (unsigned char) val;
        }
    }

    for (int i = 0; i < image->height; i++) {
        for (int j = 0; j < image->width; j++) {
            image->pixels[i][j] = temp->pixels[i][j];
        }
    }

    pgm_free(temp);
}

// Calcul des angles du gradient
double **gradient_angle(pgm_t *grad_x, pgm_t *grad_y) {
    double **angle = malloc(grad_x->height * sizeof(double *));
    for (int i = 0; i < grad_x->height; i++) {
        angle[i] = malloc(grad_x->width * sizeof(double));
        for (int j = 0; j < grad_x->width; j++) {
            angle[i][j] = atan2(grad_y->pixels[i][j], grad_x->pixels[i][j]);
        }
    }
    return angle;
}

// Suppression des non-maxima
void non_maxima_suppression(pgm_t *norm, double **angle) {
    pgm_t *temp = pgm_alloc(norm->width, norm->height, norm->max_value);
    for (int i = 1; i < norm->height - 1; i++) {
        for (int j = 1; j < norm->width - 1; j++) {
            double a = angle[i][j] * 180 / M_PI;
            a = (a < 0) ? a + 180 : a;

            unsigned char q = 255;
            unsigned char r = 255;

            // Angle 0
            if ((a >= 0 && a < 22.5) || (a >= 157.5 && a <= 180)) {
                q = norm->pixels[i][j + 1];
                r = norm->pixels[i][j - 1];
            }
            // Angle 45
            else if (a >= 22.5 && a < 67.5) {
                q = norm->pixels[i + 1][j - 1];
                r = norm->pixels[i - 1][j + 1];
            }
            // Angle 90
            else if (a >= 67.5 && a < 112.5) {
                q = norm->pixels[i + 1][j];
                r = norm->pixels[i - 1][j];
            }
            // Angle 135
            else if (a >= 112.5 && a < 157.5) {
                q = norm->pixels[i - 1][j - 1];
                r = norm->pixels[i + 1][j + 1];
            }

            if (norm->pixels[i][j] >= q && norm->pixels[i][j] >= r) {
                temp->pixels[i][j] = norm->pixels[i][j];
            } else {
                temp->pixels[i][j] = 0;
            }
        }
    }

    for (int i = 0; i < norm->height; i++) {
        for (int j = 0; j < norm->width; j++) {
            norm->pixels[i][j] = temp->pixels[i][j];
        }
    }

    pgm_free(temp);
}

// Seuil par hystérésis
void hysteresis_thresholding(pgm_t *image, float seuil_haut, float seuil_bas) {
    unsigned char max_val = max_pgm(image);
    unsigned char high = (unsigned char) (seuil_haut * max_val);
    unsigned char low = (unsigned char) (seuil_bas * max_val);

    for (int i = 1; i < image->height; i++) {
        for (int j = 1; j < image->width; j++) {
            if (image->pixels[i][j] >= high) {
                image->pixels[i][j] = 255;
            } else if (image->pixels[i][j] <= low) {
                image->pixels[i][j] = 0;
            } else {
                int found = 0;
                for (int k = -1; k <= 1; k++) {
                    for (int l = -1; l <= 1; l++) {
                        if (image->pixels[i + k][j + l] >= high) {
                            found = 1;
                            break;
                        }
                    }
                    if (found) break;
                }
                image->pixels[i][j] = found ? 255 : 0;
            }
        }
    }
}

// Détecteur de contours de Canny
pgm_t *canny_edge_detector(pgm_t *image, double sigma, int n) {
    gaussian_blur(image, sigma, n);

    pgm_t *grad_x = naive_x(image);
    pgm_t *grad_y = naive_y(image);

    double **angle = gradient_angle(grad_x, grad_y);
    pgm_t *norm = naive_edge_detector(image);

    non_maxima_suppression(norm, angle);
    hysteresis_thresholding(norm, 0.2, 0.1);

    for (int i = 0; i < image->height; i++) {
        free(angle[i]);
    }
    free(angle);
    pgm_free(grad_x);
    pgm_free(grad_y);

    return norm;
}
