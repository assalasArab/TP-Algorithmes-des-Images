#ifndef IMAGE_H
#define IMAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>


// Définition des structures
typedef struct {
    int width, height, max_value;
    unsigned char **pixels;
} pgm_t;

typedef struct {
    unsigned char r, g, b;
} rgb_t;

typedef struct {
    int width, height, max_value;
    rgb_t **pixels;
} ppm_t;

typedef struct {
    double R, G, B;
} double_rgb_t;

// Prototypes des fonctions pour PGM
pgm_t *empty_image(int value_max, int height, int width);
void highlight_rectangle_pgm(pgm_t *image, int x, int y, int height, int width);
pgm_t *pgm_alloc(int width, int height, int max_value);
void pgm_free(pgm_t *image);
pgm_t *pgm_read_asc(const char *fname);
int pgm_write_asc(const char *fname, pgm_t *image);
unsigned char max_pgm(pgm_t *image);
pgm_t *naive_x(pgm_t *image);
pgm_t *naive_y(pgm_t *image);
pgm_t *naive_edge_detector(pgm_t *image);
pgm_t *sobel_edge_detector(pgm_t *image);
double average_pixels_pgm(pgm_t *image);

// Prototypes des fonctions pour PPM
void highlight_rectangle_ppm(ppm_t *image, int x, int y, int height, int width);
ppm_t *ppm_alloc(int width, int height, int max_value);
void ppm_free(ppm_t *image);
ppm_t *ppm_read_asc(const char *fname);
int ppm_write_asc(const char *fname, ppm_t *image);
ppm_t *ppm_read_bin(const char *fname);
int ppm_write_bin(const char *fname, ppm_t *image);
void ppm_negative(ppm_t *src, ppm_t *dst);
void ppm_extract(const char *fname, ppm_t *image, int dx, int dy, int width, int height);
int **ppm_get_histogram(ppm_t *image);
int ppm_write_histogram(const char *fname, ppm_t *image);
void ppm_to_pgm(ppm_t *src, pgm_t *dst);
double_rgb_t average_pixels_ppm(ppm_t *image);

#endif // IMAGE_H
