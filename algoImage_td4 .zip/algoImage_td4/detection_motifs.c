#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

// TD pas fini
// Définition des structures
typedef struct
{
    int width, height, max_value;
    unsigned char **pixels;
} pgm_t;

typedef struct
{
    unsigned char r, g, b;
} rgb_t;

typedef struct
{
    int width, height, max_value;
    rgb_t **pixels;
} ppm_t;

typedef struct
{
    double R, G, B;
} double_rgb_t;

// Q- 1.1 Question 1 Créer une fonction pgm_t *empty_image
pgm_t *empty_image(int value_max, int height, int width)
{
    pgm_t *empty_pgm = pgm_alloc(width, height, value_max);
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            empty_pgm->pixels[i][j] = 0;
        }
    }
    return empty_pgm;
}
// Q- 1.2 Question 2 Créer les fonctions void highlight_rectangle_pgm
void highlight_rectangle_pgm(pgm_t *image, int x, int y, int height, int width)
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            if (i < x || i > (x + height) || j < y || j > (y + width))
            {
                image->pixels[i][j] = image->pixels[i][j] / 3;
            }
        }
    }
}

// Q- 1.2 Question 2 Créer les fonctions void highlight_rectangle_ppm

void highlight_rectangle_ppm(ppm_t *image, int x, int y, int height, int width)
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
            if (i < x || i > (x + height) || j < y || j > (y + width))
            {
                image->pixels[i][j].r /= 3;
                image->pixels[i][j].g /= 3;
                image->pixels[i][j].b /= 3;
            }
    }
}
// Exercice 2. Calcul de la Corrélation Croisée Normalisée

double average_pixels_pgm(pgm_t *image)
{
    double moy;
    for (int i = 0; i < image->height; i++)
        for (int j = 0; j < image->width; j++)
        {
            moy += image->pixels[i][j];
        }
    moy = moy / (image->height * image->width);

    return moy;
}

double_rgb_t average_pixels_ppm(ppm_t *image)
{

    double_rgb_t moyenne;

    for (int i = 0; i < image->height; i++)
        for (int j = 0; j < image->width; j++)
        {
            moyenne.R += image->pixels[i][j].r;
            moyenne.G += image->pixels[i][j].g;
            moyenne.B += image->pixels[i][j].b;
        }
    moyenne.R = moyenne.R / (image->height * image->width);
    moyenne.G = moyenne.G / (image->height * image->width);
    moyenne.B = moyenne.B / (image->height * image->width);

    return moyenne;
}
