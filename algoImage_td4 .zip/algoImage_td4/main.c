#include <stdio.h>
#include <stdlib.h>
#include "image.h"
#include <string.h>

void display_menu() {
    printf("Menu:\n");
    printf("1. Créer une image PGM vide\n");
    printf("2. Souligner un rectangle dans une image PGM\n");
    printf("3. Lire une image PGM (ASCII)\n");
    printf("4. Écrire une image PGM (ASCII)\n");
    printf("5. Calculer la moyenne des pixels pour PGM\n");
    printf("6. Calculer la moyenne des pixels pour PPM\n");
    printf("7. Quitter\n");
}

int main() {
    int choice;
    pgm_t *pgm_image = NULL;
    ppm_t *ppm_image = NULL;
    char filename[100];

    do {
        display_menu();
        printf("Entrez votre choix: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Entrez la largeur, la hauteur et la valeur maximale: ");
                int width, height, max_value;
                scanf("%d %d %d", &width, &height, &max_value);
                pgm_image = empty_image(max_value, height, width);
                printf("Image PGM vide créée.\n");
                break;

            case 2:
                if (pgm_image == NULL) {
                    printf("Aucune image PGM chargée.\n");
                } else {
                    int x, y, rect_width, rect_height;
                    printf("Entrez les coordonnées (x, y), la largeur et la hauteur du rectangle: ");
                    scanf("%d %d %d %d", &x, &y, &rect_width, &rect_height);
                    highlight_rectangle_pgm(pgm_image, x, y, rect_height, rect_width);
                    printf("Rectangle souligné dans l'image PGM.\n");
                }
                break;
            case 3:
                printf("Entrez le nom du fichier à lire: ");
                scanf("%s", filename);
                pgm_image = pgm_read_asc(filename);
                printf("Image PGM lue depuis %s.\n", filename);
                break;

            case 4:
                if (pgm_image == NULL) {
                    printf("Aucune image PGM chargée.\n");
                } else {
                    printf("Entrez le nom du fichier à écrire: ");
                    scanf("%s", filename);
                    pgm_write_asc(filename, pgm_image);
                    printf("Image PGM écrite dans %s.\n", filename);
                }
                break;

            case 5:
                if (pgm_image == NULL) {
                    printf("Aucune image PGM chargée.\n");
                } else {
                    double avg = average_pixels_pgm(pgm_image);
                    printf("Moyenne des pixels de l'image PGM: %.2f\n", avg);
                }
                break;

            case 6:
                printf("Entrez le nom du fichier PPM à lire: ");
                scanf("%s", filename);
                ppm_image = ppm_read_asc(filename);
                if (ppm_image == NULL) {
                    printf("Erreur lors de la lecture du fichier PPM.\n");
                } else {
                    double_rgb_t avg_rgb = average_pixels_ppm(ppm_image);
                    printf("Moyenne des pixels de l'image PPM: R=%.2f, G=%.2f, B=%.2f\n", avg_rgb.R, avg_rgb.G, avg_rgb.B);
                    ppm_free(ppm_image);
                    ppm_image = NULL;
                }
                break;

            case 7:
                break;

            default:
                printf("Choix invalide, veuillez réessayer.\n");
        }
    } while (choice != 9);

    if (pgm_image != NULL) {
        pgm_free(pgm_image);
    }

    if (ppm_image != NULL) {
        ppm_free(ppm_image);
    }

    return 0;
}
