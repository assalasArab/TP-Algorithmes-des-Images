#include "image.h"
#include <string.h>

// Allocation d'une structure PGM
pgm_t *pgm_alloc(int width, int height, int max_value) {
    pgm_t *image = malloc(sizeof(pgm_t));
    image->width = width;
    image->height = height;
    image->max_value = max_value;
    image->pixels = malloc(height * sizeof(unsigned char *));
    for (int i = 0; i < height; i++) {
        image->pixels[i] = malloc(width * sizeof(unsigned char));
    }
    return image;
}

// Libération de la mémoire d'une structure PGM
void pgm_free(pgm_t *image) {
    for (int i = 0; i < image->height; i++) {
        free(image->pixels[i]);
    }
    free(image->pixels);
    free(image);
}


// Lecture d'une image PGM en ASCII
pgm_t *pgm_read_asc(const char *fname) {
    int hauteur, largeur;
    pgm_t *S;
    char *commentaire = NULL;
    size_t len = 0;
    FILE *fic = fopen(fname, "r");

    if (fic != NULL) {
        // Ignorer les valeurs inutiles
        getline(&commentaire, &len, fic);
        while (commentaire[0] == '#' || commentaire[0] == 'P') {
            getline(&commentaire, &len, fic); // à la fin on a height et width dans commentaire
        }

        // Allocation et initialisation de la structure PGM
        S = (pgm_t *)malloc(sizeof(pgm_t));
        if (S == NULL) {
            fprintf(stderr, "Erreur d'allocation de mémoire pour la structure PGM.\n");
            exit(EXIT_FAILURE);
        }

        // Mise en place de width et height
        sscanf(commentaire, "%d %d", &S->width, &S->height);

        // Mise en place de max_value
        fscanf(fic, "%d", &S->max_value);

        // Allocation du tableau
        S->pixels = (unsigned char **)malloc(S->height * sizeof(unsigned char *));
        for (hauteur = 0; hauteur < S->height; hauteur++) {
            S->pixels[hauteur] = (unsigned char *)malloc(S->width * sizeof(unsigned char));
        }

        // Remplissage du tableau
        for (hauteur = 0; hauteur < S->height; hauteur++) {
            for (largeur = 0; largeur < S->width; largeur++) {
                fscanf(fic, "%hhu", &S->pixels[hauteur][largeur]);
                printf("%hhu",S->pixels[hauteur][largeur]);
            }
        }
        fclose(fic);
        if (commentaire)
            free(commentaire);
    } else {
        printf("Erreur d'ouverture du fichier");
        exit(EXIT_FAILURE);
    }

    return S;
}


// Écriture d'une image PGM en ASCII
int pgm_write_asc(const char *fname, pgm_t *image) {
    int i, j;
    FILE *fic = fopen(fname, "w");

    if (fic == NULL) {
        printf("Erreur d'ouverture du fichier");
        return -1;
    }

    fprintf(fic, "P2\n");
    fprintf(fic, "%d %d\n", image->width, image->height);
    fprintf(fic, "%d\n", image->max_value);
    for (i = 0; i < image->height; i++) {
        for (j = 0; j < image->width; j++) {
            fprintf(fic, "%d\n", image->pixels[i][j]);
        }
    }
    fclose(fic);
    return 0;
}

// Fonction pour obtenir la valeur maximale des pixels d'une image PGM
unsigned char max_pgm(pgm_t *image) {
    unsigned char max_val = 0;
    for (int i = 0; i < image->height; i++) {
        for (int j = 0; j < image->width; j++) {
            if (image->pixels[i][j] > max_val) {
                max_val = image->pixels[i][j];
            }
        }
    }
    return max_val;
}

// Détecteur de contours naïf horizontal
pgm_t *naive_x(pgm_t *image) {
    pgm_t *result = pgm_alloc(image->width, image->height, image->max_value);
    for (int i = 1; i < image->height - 1; i++) {
        for (int j = 1; j < image->width - 1; j++) {
            result->pixels[i][j] = abs(image->pixels[i + 1][j] - image->pixels[i - 1][j]);
        }
    }
    return result;
}

// Détecteur de contours naïf vertical
pgm_t *naive_y(pgm_t *image) {
    pgm_t *result = pgm_alloc(image->width, image->height, image->max_value);
    for (int i = 1; i < image->height - 1; i++) {
        for (int j = 1; j < image->width - 1; j++) {
            result->pixels[i][j] = abs(image->pixels[i][j + 1] - image->pixels[i][j - 1]);
        }
    }
    return result;
}

// Détecteur de contours naïf
pgm_t *naive_edge_detector(pgm_t *image) {
    pgm_t *grad_x = naive_x(image);
    pgm_t *grad_y = naive_y(image);
    pgm_t *result = pgm_alloc(image->width, image->height, image->max_value);

    unsigned char max_grad = 0;
    for (int i = 1; i < image->height - 1; i++) {
        for (int j = 1; j < image->width - 1; j++) {
            unsigned char grad = sqrt(pow(grad_x->pixels[i][j], 2) + pow(grad_y->pixels[i][j], 2));
            result->pixels[i][j] = grad;
            if (grad > max_grad) {
                max_grad = grad;
            }
        }
    }

    for (int i = 1; i < image->height - 1; i++) {
        for (int j = 1; j < image->width - 1; j++) {
            result->pixels[i][j] = (result->pixels[i][j] * 255) / max_grad;
        }
    }

    pgm_free(grad_x);
    pgm_free(grad_y);
    return result;
}

// Détecteur de contours Sobel
pgm_t *sobel_edge_detector(pgm_t *image) {
    int sobel_x[3][3] = {
        {-1, 0, 1},
        {-2, 0, 2},
        {-1, 0, 1}
    };
    int sobel_y[3][3] = {
        {-1, -2, -1},
        { 0,  0,  0},
        { 1,  2,  1}
    };

    pgm_t *result = pgm_alloc(image->width, image->height, image->max_value);

    for (int i = 1; i < image->height - 1; i++) {
        for (int j = 1; j < image->width - 1; j++) {
            int gx = 0, gy = 0;
            for (int k = -1; k <= 1; k++) {
                for (int l = -1; l <= 1; l++) {
                    gx += image->pixels[i + k][j + l] * sobel_x[k + 1][l + 1];
                    gy += image->pixels[i + k][j + l] * sobel_y[k + 1][l + 1];
                }
            }
            result->pixels[i][j] = sqrt(gx * gx + gy * gy);
        }
    }

    unsigned char max_val = max_pgm(result);
    for (int i = 0; i < result->height; i++) {
        for (int j = 0; j < result->width; j++) {
            result->pixels[i][j] = (result->pixels[i][j] * 255) / max_val;
        }
    }

    return result;
}
