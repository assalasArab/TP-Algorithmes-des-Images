#include "image.h"
#include <string.h>

// Allocation d'une structure PPM
ppm_t *ppm_alloc(int width, int height, int max_value) {
    ppm_t *S = (ppm_t *)malloc(sizeof(ppm_t));
    if (S == NULL) {
        fprintf(stderr, "Erreur d'allocation de mémoire pour la structure PPM.\n");
        exit(EXIT_FAILURE);
    }

    S->height = height;
    S->width = width;
    S->max_value = max_value;

    // Allocation dynamique
    S->pixels = (rgb_t **)malloc(height * sizeof(rgb_t *));
    if (S->pixels == NULL) {
        fprintf(stderr, "Erreur d'allocation de mémoire pour les pixels.\n");
        free(S);
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < height; i++) {
        S->pixels[i] = (rgb_t *)malloc(width * sizeof(rgb_t));
        if (S->pixels[i] == NULL) {
            fprintf(stderr, "Erreur d'allocation de mémoire pour les pixels.\n");
            for (int j = 0; j < i; j++) {
                free(S->pixels[j]);
            }
            free(S->pixels);
            free(S);
            exit(EXIT_FAILURE);
        }
        // Initialisation à zéro
        memset(S->pixels[i], 0, width * sizeof(rgb_t));
    }

    return S;
}


// Libération de la mémoire d'une structure PPM
void ppm_free(ppm_t *image) {
    for (int i = 0; i < image->height; i++) {
        free(image->pixels[i]);
    }
    free(image->pixels);
    free(image);
}

// Lecture d'une image PPM en ASCII
ppm_t *ppm_read_asc(const char *fname) {
    int hauteur, largeur;
    ppm_t *S;
    char *commentaire = NULL;
    size_t len = 0;
    FILE *fic = fopen(fname, "r");

    if (fic != NULL) {
        // Ignorer les valeurs inutiles
        getline(&commentaire, &len, fic);
        while (commentaire[0] == '#' || commentaire[0] == 'P') {
            getline(&commentaire, &len, fic); // à la fin on a height et width dans commentaire
        }

        // Allocation et initialisation de la structure PPM
        S = (ppm_t *)malloc(sizeof(ppm_t));
        if (S == NULL) {
            fprintf(stderr, "Erreur d'allocation de mémoire pour la structure PPM.\n");
            exit(EXIT_FAILURE);
        }

        // Mise en place de width et height
        sscanf(commentaire, "%d %d", &S->width, &S->height);

        // Mise en place de max_value
        fscanf(fic, "%d", &S->max_value);

        // Allocation du tableau
        S->pixels = (rgb_t **)malloc(S->height * sizeof(rgb_t *));
        for (hauteur = 0; hauteur < S->height; hauteur++) {
            S->pixels[hauteur] = (rgb_t *)malloc(S->width * sizeof(rgb_t));
        }

        // Remplissage du tableau
        for (hauteur = 0; hauteur < S->height; hauteur++) {
            for (largeur = 0; largeur < S->width; largeur++) {
                fscanf(fic, "%hhu %hhu %hhu", &S->pixels[hauteur][largeur].r, &S->pixels[hauteur][largeur].g, &S->pixels[hauteur][largeur].b);
            }
        }
        fclose(fic);
        if (commentaire)
            free(commentaire);
    } else {
        printf("Erreur d'ouverture du fichier");
        exit(EXIT_FAILURE);
    }

    return S;
}


// Écriture d'une image PPM en ASCII
int ppm_write_asc(const char *fname, ppm_t *image) {
    int i, j;
    FILE *fic = fopen(fname, "w");

    if (fic == NULL) {
        printf("Erreur d'ouverture du fichier");
        return -1;
    }

    fprintf(fic, "P3\n");
    fprintf(fic, "%d %d\n", image->width, image->height);
    fprintf(fic, "%d\n", image->max_value);
    for (i = 0; i < image->height; i++) {
        for (j = 0; j < image->width; j++) {
            fprintf(fic, "%d %d %d\n", image->pixels[i][j].r, image->pixels[i][j].g, image->pixels[i][j].b);
        }
    }
    fclose(fic);
    return 0;
}



// Lecture d'une image PPM en binaire
ppm_t *ppm_read_bin(const char *fname) {
    FILE *file = fopen(fname, "rb");
    if (!file) return NULL;

    ppm_t *image = malloc(sizeof(ppm_t));
    fscanf(file, "P6\n%d %d\n%d\n", &image->width, &image->height, &image->max_value);

    image->pixels = malloc(image->height * sizeof(rgb_t *));
    for (int i = 0; i < image->height; i++) {
        image->pixels[i] = malloc(image->width * sizeof(rgb_t));
        fread(image->pixels[i], sizeof(rgb_t), image->width, file);
    }

    fclose(file);
    return image;
}

// Écriture d'une image PPM en binaire
int ppm_write_bin(const char *fname, ppm_t *image) {
    FILE *file = fopen(fname, "wb");
    if (!file) return 1;

    fprintf(file, "P6\n%d %d\n%d\n", image->width, image->height, image->max_value);
    for (int i = 0; i < image->height; i++) {
        fwrite(image->pixels[i], sizeof(rgb_t), image->width, file);
    }

    fclose(file);
    return 0;
}

// Application du filtre négatif à une image PPM
void ppm_negative(ppm_t *src, ppm_t *dst) {
    dst->width = src->width;
    dst->height = src->height;
    dst->max_value = src->max_value;
    dst->pixels = malloc(src->height * sizeof(rgb_t *));
    for (int i = 0; i < src->height; i++) {
        dst->pixels[i] = malloc(src->width * sizeof(rgb_t));
        for (int j = 0; j < src->width; j++) {
            dst->pixels[i][j].r = src->max_value - src->pixels[i][j].r;
            dst->pixels[i][j].g = src->max_value - src->pixels[i][j].g;
            dst->pixels[i][j].b = src->max_value - src->pixels[i][j].b;
        }
    }
}

// Extraction d'une sous-image d'une image PPM
void ppm_extract(const char *fname, ppm_t *image, int dx, int dy, int width, int height) {
    FILE *file = fopen(fname, "w");
    if (!file) return;

    fprintf(file, "P3\n%d %d\n%d\n", width, height, image->max_value);
    for (int i = dy; i < dy + height; i++) {
        for (int j = dx; j < dx + width; j++) {
            fprintf(file, "%d %d %d ", image->pixels[i][j].r, image->pixels[i][j].g, image->pixels[i][j].b);
        }
        fprintf(file, "\n");
    }

    fclose(file);
}

// Calcul de l'histogramme des pixels d'une image PPM
int **ppm_get_histogram(ppm_t *image) {
    int **histogram = malloc(3 * sizeof(int *));
    for (int i = 0; i < 3; i++) {
        histogram[i] = calloc(image->max_value + 1, sizeof(int));
    }
    for (int i = 0; i < image->height; i++) {
        for (int j = 0; j < image->width; j++) {
            histogram[0][image->pixels[i][j].r]++;
            histogram[1][image->pixels[i][j].g]++;
            histogram[2][image->pixels[i][j].b]++;
        }
    }
    return histogram;
}

// Écriture de l'histogramme d'une image PPM dans un fichier
int ppm_write_histogram(const char *fname, ppm_t *image) {
    FILE *file = fopen(fname, "w");
    if (!file) return 1;

    int **histogram = ppm_get_histogram(image);
    for (int i = 0; i <= image->max_value; i++) {
        fprintf(file, "%d %d %d %d\n", i, histogram[0][i], histogram[1][i], histogram[2][i]);
    }

    for (int i = 0; i < 3; i++) {
        free(histogram[i]);
    }
    free(histogram);
    fclose(file);
    return 0;
}

// Conversion d'une image PPM en PGM
void ppm_to_pgm(ppm_t *src, pgm_t *dst) {
    dst->width = src->width;
    dst->height = src->height;
    dst->max_value = src->max_value;
    dst->pixels = malloc(src->height * sizeof(unsigned char *));
    for (int i = 0; i < src->height; i++) {
        dst->pixels[i] = malloc(src->width * sizeof(unsigned char));
        for (int j = 0; j < src->width; j++) {
            dst->pixels[i][j] = 0.3 * src->pixels[i][j].r + 0.59 * src->pixels[i][j].g + 0.11 * src->pixels[i][j].b;
        }
    }
}
